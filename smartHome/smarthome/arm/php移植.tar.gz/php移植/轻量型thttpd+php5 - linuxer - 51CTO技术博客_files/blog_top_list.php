
var start = 1;

var _html = '<div class="blogpopMain"><div class="l">'
          + '<a href="http://blog.51cto.com/zt/406" target="_blank"><img src="http://blog.51cto.com/image/blog_top/upload/1352108817_index.jpg" width="105" height="105" /></a>'
          + '<p><a href="http://blog.51cto.com/zt/406" target="_blank">Lync Server 2010</a></p></div>'
          + '<div class="r"><h4 style="text-align:left;"><a href="http://zuiniuwang.blog.51cto.com/3709988/1049964" target="_blank">ƻ�������·粨����˵�ʱ����</a></h4>'
          + '<ul>'
          + '<li><a href="http://eilfei2000.blog.51cto.com/2956473/1048951" target="_blank">����Ϸ̸�������Ժ�������</a></li>'
          + '<li><a href="http://hachiwolf.blog.51cto.com/4150000/1048350" target="_blank">��д���͵ĳ�����ʲô�أ�</a></li>'
          + '<li><a href="http://genuinecx.blog.51cto.com/2890523/1047971" target="_blank">Ԫ�������Bug����ô��</a></li>'
          + '<li><a href="http://www.diaochapai.com/survey647039" target="_blank"style="color:red;">2012���IT���ʹ�������֪���٣�</a></li>'
          + '</ul>'
          + '</div></div>'
          + '';

jQuery('#showMessagerDim').show();

jQuery(function(){
//window.onload=function(){
   if(get_cookie('blog_top')==''&&start==1){
//	 show_pop();
	    jQuery.messager.showblogtop('', _html);
        var date=new Date();
	    var day = 1352304000000;//
	    date.setTime(day);
	    var test = date.getTime();
	    document.cookie="blog_top=yes;domain=.blog.51cto.com;expires="+date.toGMTString()+";path=/;";
    }
	jQuery("#showMessagerDim").click(function(){
		jQuery.messager.showblogtop('', _html);
		//removeIframe();
	});
//}
});


function get_cookie(Name) {
    var search = Name + "=";
    var returnvalue = "";
    if (document.cookie.length > 0) {
        offset = document.cookie.indexOf(search);
        if (offset != -1) {
            offset += search.length;

            end1 = document.cookie.indexOf(";", offset);

            if (end1 == -1)
            end1 = document.cookie.length;
            returnvalue=unescape(document.cookie.substring(offset, end1));
        }
    }
    return returnvalue;
}

