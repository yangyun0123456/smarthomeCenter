document.write("<img src=\"http://ucenter.51cto.com/avatar.php?uid=400447&size=middle\" id=userface>");
