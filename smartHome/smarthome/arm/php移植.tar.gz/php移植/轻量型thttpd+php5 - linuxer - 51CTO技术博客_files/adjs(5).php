var phpadsbanner = '';


document.write(phpadsbanner);
