﻿var ad_type = 'ibm407';
var ad_sc = '<script type="text/javascript" '
    + 'src="http://ad.csdn.net/scripts/ad-' + ad_type + '.js"'
    + '></'
    + 'script>';
document.writeln(ad_sc);
