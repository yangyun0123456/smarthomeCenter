#!/bin/bash
# Run this to initialise the file system for the test runs.
   ./yaffs_test  -u -i yaffs2
