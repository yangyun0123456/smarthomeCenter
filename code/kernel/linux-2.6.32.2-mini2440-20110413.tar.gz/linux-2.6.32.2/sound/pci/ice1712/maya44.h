#ifndef __SOUND_MAYA44_H
#define __SOUND_MAYA44_H

#define MAYA44_DEVICE_DESC		"{ESI,Maya44},"

#define VT1724_SUBDEVICE_MAYA44		0x34315441	/* Maya44 */

extern struct snd_ice1712_card_info  snd_vt1724_maya44_cards[];

#endif	/* __SOUND_MAYA44_H */
