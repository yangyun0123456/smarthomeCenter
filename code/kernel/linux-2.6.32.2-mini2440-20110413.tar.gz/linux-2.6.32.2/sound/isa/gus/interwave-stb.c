#define SNDRV_STB
#include "interwave.c"
